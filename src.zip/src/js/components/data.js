class Character {
    constructor(key, name, role, portrait, message) {
      this.key = key;
      this.name = name;
      this.role = role;
      this.portrait = portrait;
      this.message = message
    }
  }


